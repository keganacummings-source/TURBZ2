DUNGEON CRAWL STONE SOUP — ORGANIZED ASSET CATALOG
=================================================

This archive reorganizes the supplied image pack into a searchable asset library.

FOLDERS
-------
00_Race_Catalog/
  One folder per race/species detected from filenames. Contains that race's base
  sprites and filename-matched race-specific visuals, armor, weapons, items and
  creatures. Filename matches are best-effort catalog suggestions, not a claim
  that every matched asset is exclusively equippable by that race.
  Generic assets that have no race clue remain in Asset_Library for shared use.

Asset_Library/
  01_Characters/  player bases, layers and visual components
  02_Worldbuilding/Terrain_and_Props/  floor, wall, water, trees, doors, gateways,
      traps, altars, shops, statues and vault tile assets
  03_Items_Armor_Weapons/  inventory items, armor, weapons, books, potions, etc.
  04_Monsters_and_Creatures/
  05_Effects/
  06_UI_Icons/
  07_Emissaries/
  08_Miscellaneous/
  09_Other/

CATALOG FILES
-------------
asset_catalog.csv: every included source file, its sorted library category, a
  best-effort race match (or Shared / not race-specific), and byte size.
race_catalog_summary.csv: counts per race folder.
worldbuilding_catalog.csv: all terrain/prop tiles, with original subfolder path.
armor_weapon_catalog.csv: armor and weapon assets, with original subfolder path.

IMPORTANT NOTES
---------------
- Original relative paths are preserved inside Asset_Library to keep asset
  provenance clear and avoid filename collisions.
- The Race Catalog intentionally duplicates matched files for convenient
  race-pack assembly; the central Asset_Library remains the complete catalog.
- This source pack is a tile/sprite collection, not a fully defined equipment
  database. Where filenames do not identify a race, items stay shared rather
  than being assigned to a race without evidence.
- Asset names and images are preserved; files are not recolored or edited.

EXTRA SET BROWSERS
------------------
03_Armor_Set_Catalog/ groups armor sprites into named families (dragon armor
variants, chain mail, plate, robes, shields, etc.). Individual source filenames
are retained in each family folder for identification.
04_Weapon_Set_Catalog/ groups weapons into swords, axes, polearms, blunt,
ranged, staves/rods, daggers/knives, shields and other weapons.
These are visual asset families inferred from filenames, not complete game
loadouts or claims that all pieces form a matching equipable set.
