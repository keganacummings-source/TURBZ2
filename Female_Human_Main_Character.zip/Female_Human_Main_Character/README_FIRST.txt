FEMALE HUMAN — MAIN CHARACTER ASSET PACK

Purpose
A focused pack for building the game's female Human main character, with shared item/armor/weapon sprites that are not explicitly marked as belonging to another race.

Folders
01_Character_Base: female Human base sprite and humanoid transformation sprite.
02_Armor: shared armor item sprites.
03_Weapons: shared weapon item sprites.
04_Consumables_and_Utility_Items: potions, scrolls, food, wands, rods.
05_Accessories_and_Magic_Items: rings, amulets, staves, books.
06_Other_Items: other shared item categories.
07_Female_Character_Visuals: explicitly female-coded hair and clothing/appearance layers found in the source pack.
Catalogs: CSV indexes mapping copied assets to their original paths.

Compatibility note
The source pack is a sprite/asset collection, not a complete equipment-rules database. Item sprites are usually shared visuals and do not encode every gameplay restriction. This pack includes shared items and items explicitly matched to Human by the source catalog, excludes items explicitly matched to other races, and omits barding. Confirm gameplay equip rules in your own game before treating every item as wearable. Female-specific visuals are a separate optional layer collection; not every named style is guaranteed to layer correctly with every body/armor sprite.

Files are copied without modifying the original images.
